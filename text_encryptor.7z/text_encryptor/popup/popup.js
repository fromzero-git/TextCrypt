let encrypt__button = document.querySelector('.choose__action__encrypt')
let decrypt__button = document.querySelector('.choose__action__decrypt')
let key_input = document.querySelector('.key_input')
let switcher = document.querySelector('.checkbox__switcher')
let new_window = document.querySelector('.new_window')
let send_button = document.querySelector('.operation__button')
let input_text = document.querySelector('.text_input')
let output_text = document.querySelector('.output')
let savePasswords = document.querySelector('.saveKeyButton')
const modal = document.querySelector('.modal')
const modal_bgd = document.querySelector('.modal_background')
let output_warning = document.querySelector('.output_text')

// Удобство и сохранение методов в локальном хранилище
if (localStorage.getItem('method')){
    if (localStorage.getItem('method') === 'decrypt'){
        decrypt__button.classList.add('active')
    } else{
        encrypt__button.classList.add('active')
    }
} else{
    encrypt__button.classList.add('active')
}
if (localStorage.getItem('key_input')){
    if (localStorage.getItem('key_input') === 'true'){
        switcher.checked = true
        key_input.disabled = true
    } else{
        switcher.checked = false
        key_input.disabled = false
    }
}

//открытие нового окна
new_window.addEventListener('click', () =>{
        browser.windows.create({
        url: "popup.html",
        type: "popup",
        width: 450,
        height: 700
    });
})

//смена методов
decrypt__button.addEventListener('click', () =>{
    if (encrypt__button.classList.contains('active')){
        encrypt__button.classList.remove('active');
    }
    decrypt__button.classList.add('active')
    localStorage.setItem("method", "decrypt")
})
encrypt__button.addEventListener('click', () =>{
    if (decrypt__button.classList.contains('active')){
        decrypt__button.classList.remove('active');
    }
    encrypt__button.classList.add('active')
    localStorage.setItem("method", "encrypt");
})
//выбор пароля
switcher.addEventListener('click', () =>{
    if (switcher.checked){
        key_input.disabled = true
        localStorage.setItem('key_input', 'true')
    } else{
        key_input.disabled = false
        localStorage.setItem('key_input', 'false')
    }
})
//отправка данных для шифрования/дешифрования
send_button.addEventListener('click', async () => {
    let method = localStorage.getItem('method') || 'encrypt';
    let key;

    if (switcher.checked === true && method === 'encrypt') {
        key = await getEncryptionKey();
        if (!key) {
            modal.style.display = 'flex';
            modal_bgd.style.display = 'block'
            return;
        }
    } else if (switcher.checked === true && method === 'decrypt') {
        key = await getDecryptionKey();
        if (!key) {
            modal.style.display = 'flex';
            modal_bgd.style.display = 'block'
            return;
        }
    } else {
        key = key_input.value;
    }

    let inText = input_text.value
    if (method === 'encrypt'){
        output_text.value = await encryptWithPassword(key, inText)
        output_warning.textContent = 'Output'
    } else{
        const decryptedText = await decryptWithPassword(key, inText)
        if (decryptedText === null) {
            output_text.textContent = ""
            output_warning.textContent = "Incorrect decryption key"
        } else {
            output_text.value = decryptedText
            output_warning.textContent = "Output"
        }
    }
})
//сохранение паролей в локальном хранилище
async function saveEncryptionKeys(encryptionKey) {
    const { encryptedText, iv } = await encryptText(encryptionKey);
    localStorage.setItem('encryptionKey', encryptedText);
    localStorage.setItem('encryptionIV', iv);
}
async function saveDecryptionKeys(decryptionKey) {
    const { encryptedText, iv } = await encryptText(decryptionKey);
    localStorage.setItem('decryptionKey', encryptedText);
    localStorage.setItem('decryptionIV', iv);
}
//получение паролей из локального хранилища
async function getEncryptionKey() {
    const encryptedText = localStorage.getItem('encryptionKey')
    const iv = localStorage.getItem('encryptionIV')
    if (encryptedText && iv) {
        try {
            return await decryptText(encryptedText, iv)
        } catch (e) {
            console.error("Ошибка расшифровки ключа:", e)
            return false;
        }
    }
    return false;
}

async function getDecryptionKey() {
    const encryptedText = localStorage.getItem('decryptionKey');
    const iv = localStorage.getItem('decryptionIV');
    if (encryptedText && iv) {
        try {
            return await decryptText(encryptedText, iv);
        } catch (e) {
            console.error("Ошибка расшифровки ключа:", e);
            return false;
        }
    }
    return false;
}
//модальное окно с сохранением постоянных паролей
savePasswords.addEventListener('click', () => {
    let encryption_key = document.querySelector('.permanentEncryptionKey').value
    let decryption_key = document.querySelector('.permanentDecryptionKey').value
        if (encryption_key && decryption_key) {
            saveEncryptionKeys(encryption_key);
            saveDecryptionKeys(decryption_key);
            modal.style.display = 'none'
            modal_bgd.style.display = 'none'
    } else {
        document.querySelector('.modal_text').textContent = 'Fill both before save keys'
    }
})
//функция получения уникального ключа
async function deriveKeyFromPassword(password, salt = null) {
    const encoder = new TextEncoder();
    salt = salt || crypto.getRandomValues(new Uint8Array(16))

    const keyMaterial = await crypto.subtle.importKey(
        "raw", encoder.encode(password), "PBKDF2", false, ["deriveKey"]
    );

    const cryptoKey = await crypto.subtle.deriveKey(
        { name: "PBKDF2", salt: salt, iterations: 200000, hash: "SHA-256" },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
    );

    return { cryptoKey, salt }
}
// функции шифрования и дешифрования на основе пароля
async function encryptWithPassword(password, plaintext) {
    const encoder = new TextEncoder();

    const { cryptoKey, salt } = await deriveKeyFromPassword(password);

    const iv = crypto.getRandomValues(new Uint8Array(12));

    const ciphertext = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv },
        cryptoKey,
        encoder.encode(plaintext)
    );

    const encryptedData = new Uint8Array(salt.length + iv.length + ciphertext.byteLength);
    encryptedData.set(salt);
    encryptedData.set(iv, salt.length);
    encryptedData.set(new Uint8Array(ciphertext), salt.length + iv.length);

    return btoa(String.fromCharCode(...encryptedData)); // Конвертируем в Base64 строку
}
async function decryptWithPassword(password, encryptedText) {
    try {
        const encryptedData = Uint8Array.from(atob(encryptedText), c => c.charCodeAt(0));

        const salt = encryptedData.slice(0, 16);
        const iv = encryptedData.slice(16, 28);
        const ciphertext = encryptedData.slice(28);

        const { cryptoKey } = await deriveKeyFromPassword(password, salt);

        const decrypted = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: iv },
            cryptoKey,
            ciphertext
        );

        const decoder = new TextDecoder();
        return decoder.decode(decrypted);

    } catch (error) {
        console.error("Ошибка расшифровки: Неверный ключ или поврежденные данные.");
        return null;
    }
}
//уникальная строка для хранения паролей
async function generateFixedKey() {
    const encoder = new TextEncoder();
    const uniqueData = `${navigator.userAgent}-fixedSalt`; // создаём уникальную строку
    const keyMaterial = await crypto.subtle.importKey(
        "raw", encoder.encode(uniqueData), "PBKDF2", false, ["deriveKey"]
    );
    return await crypto.subtle.deriveKey(
        { name: "PBKDF2", salt: encoder.encode("fixedSalt"), iterations: 100000, hash: "SHA-256" },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
    );
}
//шифрование текста перед отправкой в хранилище
async function encryptText(text) {
    const cryptoKey = await generateFixedKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encryptedData = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv },
        cryptoKey,
        new TextEncoder().encode(text)
    );
    return {
        encryptedText: btoa(String.fromCharCode(...new Uint8Array(encryptedData))),
        iv: btoa(String.fromCharCode(...iv))
    };
}
async function decryptText(encryptedText, iv) {
    const cryptoKey = await generateFixedKey();
    const decryptedData = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: Uint8Array.from(atob(iv), c => c.charCodeAt(0)) },
        cryptoKey,
        Uint8Array.from(atob(encryptedText), c => c.charCodeAt(0))
    );
    return new TextDecoder().decode(decryptedData);
}
